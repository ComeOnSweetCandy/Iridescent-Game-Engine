--physicNodeType = 2;
--physicEdgeType = 1;
--circleRadius = 1.0;

--vertexsArray1 = {0.0,0.0,1.0,0.0,1.0,1.0,0.0,1.0};

function CreateSoilPhysicNode()

	--terrainPhysicEdge = IEPhysicPolygon.Create(1);
	--terrainPhysicNode = IEPhysicNode.Create(terrainPhysicEdge,physicNodeType);
	terrainPhysicNode = nil;
	
end