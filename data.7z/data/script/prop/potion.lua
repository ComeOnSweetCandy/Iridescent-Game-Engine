function UserProp()

	print("drink me!");
	
end