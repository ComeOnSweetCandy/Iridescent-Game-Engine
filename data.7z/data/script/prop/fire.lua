propIndex = 40001;

propIcon = "fire/icon.png";
propPicked = "fire/picked.png";

function UserProp()

	IEProp.CreateFire(10.0);
	
end