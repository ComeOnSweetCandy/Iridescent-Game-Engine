propIndex = 20001;

propIcon = "medicine/icon.png";
propPicked = "medicine/picked.png";

function UserProp()

	actionNode:Cure(10);

end