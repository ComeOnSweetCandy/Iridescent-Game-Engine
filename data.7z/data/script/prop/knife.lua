propIndex = 10001;
physicNodeType = 3;
physicEdgeType = 1;
circleRadius = 0.5;
attackDistance = 2.0;
damageValue = 2.0;

propBody = "knife/body.png";
propIcon = "knife/icon.png";
propPicked = "knife/picked.png";

function UserProp()

	attackPhysicEdge = IEPhysicCircle.Create(circleRadius,32);
	collisionTrigger = IECollisionTrigger.Create(attackPhysicEdge,physicNodeType,0,120);
	damageProp = IEDamageProp.Create(propIndex, collisionTrigger, actionNode, damageValue);
	
	local nodePosition_x, nodePosition_y = actionPhysicNode:GetPosition();
	local faceDirection_x, faceDirection_y = actionNode:GetFacer();
	local skillPosition_x = faceDirection_x * attackDistance + nodePosition_x;
	local skillPosition_y = faceDirection_y * attackDistance + nodePosition_y;
	
	--IENode.SetPosition(damageProp, skillPosition_x, skillPosition_y);
	--IEPhysicNode.SetPosition(collisionTrigger, skillPosition_x,skillPosition_y);
	--IEPhysicNode.SetForward(collisionTrigger, faceDirection_x * 4, faceDirection_y * 4);
	damageProp:SetPosition(skillPosition_x, skillPosition_y);
	collisionTrigger:SetPosition(skillPosition_x, skillPosition_y);
	collisionTrigger:SetForward(faceDirection_x * 4, faceDirection_y * 4);
	
end