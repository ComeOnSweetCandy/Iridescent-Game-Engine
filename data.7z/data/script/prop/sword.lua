function UserProp()

	print("use sword!");
	
end