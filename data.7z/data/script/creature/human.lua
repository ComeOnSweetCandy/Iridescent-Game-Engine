function Born()

--local arrs = self:AroundEnemys();

--for i=#arrs,1,-1 do
    --print(arrs[i]:GetFacer());
--end

end