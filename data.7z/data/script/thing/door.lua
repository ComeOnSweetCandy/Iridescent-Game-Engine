function Init

	print("door init");

end